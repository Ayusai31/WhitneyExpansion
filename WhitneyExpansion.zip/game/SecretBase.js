(function() {
    'use strict';
    
    function isInSecretBase() {
        const condition1 = Time.weekDay === 7 && (Time.hour < 19 || (Time.hour === 19 && Time.minute === 0));//星期六并且在晚上七点前
        const condition2 = Time.schoolDay && (Time.hour > 15 || (Time.hour === 15 && Time.minute >= 0));
        //上学日的下午放学后
        const condition3 = !Time.schoolDay && Time.weekDay !== 1 && Time.weekDay !== 7;
        //非上学日并且不是星期天和星期六
        return condition1 || condition2 || condition3;
    }
    
    // 将函数暴露给游戏使用
    window.isInSecretBase = isInSecretBase;
})();